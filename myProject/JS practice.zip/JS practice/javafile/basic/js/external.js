
    document.write("This is head section "+"<br>")
    document.write("This is body section ")

