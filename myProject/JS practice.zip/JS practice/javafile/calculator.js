function appendToResult(value) {
    document.getElementById('result').value += value;
  }

  function calculateResult() {
    try {
      document.getElementById('result').value = val(document.getElementById('result').value);
    } catch (error) {
      document.getElementById('result').value = 'Error';
    }
  }

  function clearResult() {
    document.getElementById('result').value = '';
  }