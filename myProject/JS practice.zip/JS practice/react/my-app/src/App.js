
import './App.css';
// import CRUD from './CRUD';

// function App() {
//   return (
//     <CRUD/>
//   );
// }

// export default App;

import React, {useState} from "react"

import {Login} from "./Login";
import {Register} from "./Register";

function App(){
  const [currentform, setCurrentForm]=useState["Login"];
const toggleForm=(formName)=>{
  setCurrentForm(formName);
}
  return(
    <div className="App">{
      currentform ==="Login" ?<Login onFormSwitch={toggleForm} />:<Register  onFormSwitch={toggleForm}/>
}
</div>
  );
}
export default App;
