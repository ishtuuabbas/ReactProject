const newTaskInput = document.getElementById('New-task');
const addTaskButton = document.getElementById('Add-task');
const taskList = document.getElementById('Task-list');

addTaskButton.addEventListener('click', function() {
  const newTask = newTaskInput.value.trim();
  if (newTask) {
    const listItem = document.createElement('li');
    listItem.textContent = newTask;
    taskList.appendChild(listItem);
    newTaskInput.value = '';
  }
});