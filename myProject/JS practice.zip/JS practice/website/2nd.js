const crackButton = document.getElementById('crack-button');
const fortuneEl = document.getElementById('fortune');
const cookieEl = document.getElementById('cookie');

const fortunes = [
    "You will have a stroke of good luck today.",
    "A new opportunity awaits you around the corner.",
    "Follow your intuition, it will lead you in the right direction.",
    "Be kind to yourself and others, it will be rewarded.",
    "Take some time for yourself to relax and recharge.",
    "Big changes are coming your way, but don't be afraid to embrace them.",
    "Today is a good day to start something new.",
    "Don't give up on your dreams, they are worth fighting for.",
    "Believe in yourself and you can achieve anything.",
    "You are loved and appreciated, even when you don't feel it.",
];

function crackCookie() {
    cookieEl.style.display = "block";
    fortuneEl.textContent = fortunes[Math.floor(Math.random() * fortunes.length)];
}

crackButton.addEventListener('click', crackCookie);