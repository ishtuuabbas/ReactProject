const questions = [
    { question: "Which company owns the android??", choices: ["Google", "Apple", "Nokia", "Samsung"], answer: 0 },
    { question: "Which one is not the programming language ??", choices: ["Java", "Kotlin", "Notepad", "Python"], answer: 2 },
    { question: "Where you are watching this video ??", choices: ["Facebook", "Whatsapp", "Instagram", "Youtube"], answer: 3 },    
    { question: "Which company owns the Apple ??", choices: ["Google", "Apple", "Nokia", "Samsung"], answer: 1 },
 
];

let currentQuestion = 0;
let score = 0;

function displayQuestion() {
    const questionl = document.getElementById("question");
    const choicesl = document.getElementById("choices");
    questionl.textContent = questions[currentQuestion].question;
    choicesl.innerHTML = ""; 
    for (let i = 0; i < questions[currentQuestion].choices.length; i++) {
        const choicel = document.createElement("li");
        choicel.textContent = questions[currentQuestion].choices[i];
        choicel.addEventListener("click", function() {
            checkAnswer(i);
        });
        choicesl.appendChild(choicel);
    }
}

function checkAnswer(selectedChoice) {
    if (selectedChoice === questions[currentQuestion].answer) {
        score++;
        document.getElementById("Feedback").textContent = "Correct!";
    } else {
        document.getElementById("Feedback").textContent = "Incorrect. The answer is " + questions[currentQuestion].choices[questions[currentQuestion].answer];
    }
    currentQuestion++;
    if (currentQuestion === questions.length) {
        document.getElementById("Feedback").textContent = "You finished the quiz! Your score is " + score + "/" + questions.length;
        document.getElementById("Submit").disabled = true;
    } else {
        displayQuestion();
    }
}

displayQuestion();