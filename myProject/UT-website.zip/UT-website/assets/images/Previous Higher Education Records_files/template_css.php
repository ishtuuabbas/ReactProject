

.fabrikGroup {
clear: left;
}
